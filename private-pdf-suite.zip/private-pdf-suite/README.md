# PrivatePDF Suite

A free, offline, privacy-first PDF/document toolbox for Windows (macOS/Linux planned).
Files never leave your device. No account, no API keys, no cloud processing.

## Status: Milestone 0 (architecture) — see docs/

- `docs/ARCHITECTURE.md` — how the pieces fit together
- `docs/FEATURE_MATRIX.md` — full feature list, tech choices, license notes
- `docs/DEPENDENCY_INVENTORY.md` — every third-party dependency and its license
- `docs/PRIVACY.md` — the privacy claims and how they're enforced

## Repository layout

```
frontend/   React UI (Tauri webview)
backend/    Python FastAPI sidecar (local loopback API only)
engines/    Pure processing logic — pdf, images, ocr, office, compression, encryption, metadata
desktop/    Tauri (Rust) shell — spawns/manages the sidecar
tests/      pytest suite for engines + backend
docs/       architecture, feature matrix, dependency inventory, privacy docs
build/      packaging scripts (PyInstaller specs, installer config)
```

## Running the backend tests

```
pip install -r backend/requirements.txt
pytest
```

## Development principles

Free. Private. Offline. Local. Simple. Reliable. Transparent. Maintainable.
No forced accounts, no telemetry by default, no silent network calls, no fake/placeholder features.
