import { useState } from "react";
import { mergePdfs } from "./api";

export default function App() {
  const [status, setStatus] = useState("");

  async function handleMergeDemo(paths) {
    setStatus("Merging...");
    try {
      const result = await mergePdfs(paths);
      setStatus(`Done: ${result.output_path}`);
    } catch (err) {
      setStatus(`Error: ${err.message}`);
    }
  }

  return (
    <main>
      <h1>PrivatePDF</h1>
      <p>Milestone 0 scaffold — tool grid and drag/drop land in Milestone 1.</p>
      <p>{status}</p>
    </main>
  );
}
