// Thin client for talking to the local Python sidecar.
// port/token are provided by the Tauri host at startup via window.__PRIVATEPDF__
// (set from Rust before the frontend loads) — never hardcoded, never fetched
// from anywhere on the internet.

function sidecarBase() {
  const cfg = window.__PRIVATEPDF__;
  if (!cfg || !cfg.port || !cfg.token) {
    throw new Error("Sidecar connection info not available yet");
  }
  return { base: `http://127.0.0.1:${cfg.port}`, token: cfg.token };
}

export async function mergePdfs(inputPaths) {
  const { base, token } = sidecarBase();
  const res = await fetch(`${base}/organize/merge`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-privatepdf-token": token,
    },
    body: JSON.stringify({ input_paths: inputPaths }),
  });
  if (!res.ok) {
    const detail = await res.json().catch(() => ({}));
    throw new Error(detail.detail || `Request failed: ${res.status}`);
  }
  return res.json();
}
